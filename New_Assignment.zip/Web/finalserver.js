var MongoClient = require('mongodb').MongoClient;
var dbUrl = "mongodb://localhost:27017/";

(function() {
  var fs, http, qs, server, url;

  http = require('http');

  url = require('url');

  qs = require('querystring');

  fs = require('fs');

  server = http.createServer(function(req, res) {
    var action, form, formData, msg, publicPath, urlData, stringMsg;
		var response = res;
		var request = req;
    urlData = url.parse(req.url, true);
    action = urlData.pathname;
    publicPath = __dirname + "\\public\\";
   console.log(req.url);
		

       if (action === "/signup") {
       console.log("signup");
      if (req.method === "POST") {
        console.log("action = post");
        formData = '';
        msg = '';
        return req.on('data', function(data) {
          formData += data;
          
          console.log("form data="+ formData);
          return req.on('end', function() {
            var user;
            user = qs.parse(formData);
            user.id = "123456";
            msg = JSON.stringify(user);
						stringMsg = JSON.parse(msg);
						console.log("mess="+msg);
            console.log("mess="+formData);
           
						MongoClient.connect(dbUrl, function(err, db) {
  					if (err) throw err;
  					var dbo = db.db("mydb");
  					var myobj = stringMsg;
  					dbo.collection("customers").insertOne(myobj, function(err, res) {
    				if (err) throw err;
    				console.log("1 document inserted");
    				db.close();
  					});
					});
						
            return res.end("good");
          });
        });
				
      } else {
        
				sendFileContent(res, "signup.html", "text/html");
      }
				 
				 
				    }else if( action==="/login"){
       console.log("login");
      if (req.method === "POST") {
        console.log("action = post");
        formData = '';
        msg = '';
        return req.on('data', function(data) {
          formData += data;
          
          console.log("form data="+ formData);
          return req.on('end', function() {
            var user;
            user = qs.parse(formData);
            user.id = "123456";
            msg = JSON.stringify(user);
						stringMsg = JSON.parse(msg);
						console.log("mess="+msg);
            console.log("mess="+formData);
           
						MongoClient.connect(dbUrl, function(err, db) {
  					if (err) throw err;
  					var dbo = db.db("mydb");
  					var myobj = stringMsg;
  				  dbo.collection("customers").find({}).toArray(function(err, result) {
    if (err) throw err;
    console.log(result);
    db.close();
							for(var i=0;i<result.length;i++)
							if((result[i].UserName==myobj.UserName) && (result[i].Password==myobj.Password)) {
							 return res.end("Login Successful");				
							}
						
								return res.end("UserName or Password is wrong");
  					});
					});
          });
        });
      } else {
				sendFileContent(res, "login.html", "text/html");
      }
							

						}else if (action === "/FavouriteList") {
       console.log("FavouriteList");
      if (req.method === "POST") {
        console.log("action = post");
        formData = '';
        msg = '';
        return req.on('data', function(data) {
          formData += data;
          
          console.log("form data="+ formData);
          return req.on('end', function() {
            var user;
            user = qs.parse(formData);
            user.id = "123456";
            msg = JSON.stringify(user);
      stringMsg = JSON.parse(msg);
      console.log("mess="+msg);
            console.log("mess="+formData);
         
      MongoClient.connect(dbUrl, function(err, db) {
       if (err) throw err;
       var dbo = db.db("mydb");
       var myobj = stringMsg;
				
				 dbo.collection("customers").count({"Name" : "ALEX"}, function (error, count) {
        console.log(error, count);
       
        finalcount=count;
       });
       
       var myquery;
       var newvalues;
       		
       if(myobj.add1!=null){       
         myquery = { UserName:myobj.UserName};
         newvalues = { $set: { add1:myobj.add1 } };}
				
				if(myobj.add2!=null){       
          myquery = { UserName:myobj.UserName};
          newvalues = { $set: { add2:myobj.add2 } };}
				
				if(myobj.add3!=null){       
          myquery = { UserName:myobj.UserName};
          newvalues = { $set: { add3:myobj.add3 } };}
				
				  if(myobj.add4!=null){       
         myquery = { UserName:myobj.UserName};
         newvalues = { $set: { add4:myobj.add4 } };}
				
				if(myobj.add5!=null){       
          myquery = { UserName:myobj.UserName};
          newvalues = { $set: { add5:myobj.add5 } };}
				
				if(myobj.add6!=null){       
          myquery = { UserName:myobj.UserName};
          newvalues = { $set: { add6:myobj.add6 } };}
				  
if(myobj.add1!=null||myobj.add2!=null||myobj.add3!=null||myobj.add4!=null||myobj.add5!=null||myobj.add6!=null){
       dbo.collection("customers").updateOne(myquery, newvalues, function(err, res) {
    if (err) throw err;
    console.log("1 document updated");
    db.close();
     
  });
       }   
dbo.collection("customers").find({}).toArray(function(err, result) {
    if (err) throw err; console.log(result);
        for (var x=0; x<result.length; x++)
         if(result[x].UserName==myobj.UserName){
           return res.end("add1="+result[x].add1+"add2="+result[x].add2+"add3="+result[x].add3+"add4="+result[x].add4+"add5="+result[x].add5+"add6="+result[x].add6);
         } 

 });    
     });
      
          });
        });
				
				    } else {
        form = "FavouriteList.html";
        return fs.readFile(form, function(err, contents) {
          if (err !== true) {
            res.writeHead(200, {
              "Content-Type": "text/html"
            });
            return res.end(contents);
          } else {
            res.writeHead(500);
            return res.end;
          }
        });
      }
							
							
							
}else if (action === "/Counselling_Center") {
       console.log("Counselling_Center");
      if (req.method === "POST") {
        console.log("action = post");
        formData = '';
        msg = '';
        return req.on('data', function(data) {
          formData += data;
          
          console.log("form data="+ formData);
          return req.on('end', function() {
            var user;
            user = qs.parse(formData);
            user.id = "123456";
            msg = JSON.stringify(user);
      stringMsg = JSON.parse(msg);
      console.log("mess="+msg);
            console.log("mess="+formData);
         
      MongoClient.connect(dbUrl, function(err, db) {
       if (err) throw err;
       var dbo = db.db("mydb");
       var myobj = stringMsg;
				
				 dbo.collection("customers").count({"Name" : "ALEX"}, function (error, count) {
        console.log(error, count);
       
        finalcount=count;
       });
       
       var myquery;
       var newvalues;
       
				 if(myobj.add01!=null){       
         myquery = { UserName:myobj.UserName};
         newvalues = { $set: { add01:myobj.add01 } };}

				 if(myobj.add02!=null){       
         myquery = { UserName:myobj.UserName};
         newvalues = { $set: { add02:myobj.add02 } };}
				
				 if(myobj.add03!=null){       
         myquery = { UserName:myobj.UserName};
         newvalues = { $set: { add03:myobj.add03 } };}
			
				if(myobj.add04!=null){       
         myquery = { UserName:myobj.UserName};
         newvalues = { $set: { add04:myobj.add04 } };}
				
				if(myobj.add05!=null){       
         myquery = { UserName:myobj.UserName};
         newvalues = { $set: { add05:myobj.add05 } };}
				
				if(myobj.add06!=null){       
         myquery = { UserName:myobj.UserName};
         newvalues = { $set: { add06:myobj.add06 } };}
			
if(myobj.add01!=null||myobj.add02!=null||myobj.add03!=null||myobj.add04!=null||myobj.add05!=null||myobj.add06!=null){
       dbo.collection("customers").updateOne(myquery, newvalues, function(err, res) {
    if (err) throw err;
    console.log("1 document updated");
    db.close();
     
  });
       }   
dbo.collection("customers").find({}).toArray(function(err, result) {
    if (err) throw err; console.log(result);
        for (var x=0; x<result.length; x++)
         if(result[x].UserName==myobj.UserName){
           return res.end("add01="+result[x].add01+"add02="+result[x].add02+"add03="+result[x].add03+"add04="+result[x].add04+"add05="+result[x].add05+"add06="+result[x].add06);
         } 

 });    
     });
      
          });
        });
				
				    } else {
        form = "Counselling_Center.html";
        return fs.readFile(form, function(err, contents) {
          if (err !== true) {
            res.writeHead(200, {
              "Content-Type": "text/html"
            });
            return res.end(contents);
          } else {
            res.writeHead(500);
            return res.end;
          }
        });
      }


				//
    }else if( action==="/newpage"){
       res.writeHead(200, {
        "Content-Type": "text/html"
      });
      return res.end("<h1>�w����{Node.js�泾���O2</h1><p><a href=\"/Signup\">���U</a></p>");
    }
		
		
else	if(request.url === "/index"){
		//sendFileContent(response, "callajax.html", "text/html");
		sendFileContent(response, "index.html", "text/html");
	}
	else if(request.url === "/Counselling_Center"){
		sendFileContent(response, "Counselling_Center.html", "text/html");
	}else if(request.url === "/FBpage"){
		sendFileContent(response, "FBpage.html", "text/html");
	}else if(request.url === "/FavouriteList"){
		sendFileContent(response, "FavouriteList.html", "text/html");
		
	
	}else if(request.url === "/NarcoticsAnalgesics"){
		sendFileContent(response, "NarcoticsAnalgesics.html", "text/html");
	}else if(request.url === "/Hallucinogens"){
		sendFileContent(response, "Hallucinogens.html", "text/html");	
	}else if(request.url === "/Depressants"){
		sendFileContent(response, "Depressants.html", "text/html");
	}else if(request.url === "/Stimulants"){
		sendFileContent(response, "Stimulants.html", "text/html");
	}else if(request.url === "/Tranquillizers"){
		sendFileContent(response, "Tranquillizers.html", "text/html");
	}else if(request.url === "/Others"){
		sendFileContent(response, "Others.html", "text/html");
			}else if(request.url === "/index5"){
		sendFileContent(response, "index5.html", "text/html");

	}else if(request.url === "/login"){
		sendFileContent(response, "login.html", "text/html");	
		}else if(request.url === "/signup"){
		sendFileContent(response, "signup.html", "text/html");	
	}
	
	
	//Login/Signup
	else if(/^\/[a-zA-Z0-9\/]*.js$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/javascript");
	}	else if(/^\/[a-zA-Z0-9\/]*.min.js$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/javascript");
	}else if(/^\/[a-zA-Z0-9\/]*.bootstrap.bundle.min.js$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/javascript");
	}else if(/^\/[a-zA-Z0-9\/]*.contact_me.js$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/javascript");
	}
	
	
	
	else if(/^\/[a-zA-Z0-9\/]*.min.css$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/css");
	}else if(/^\/[a-zA-Z0-9\/]*.modern-business.css$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/css");
	}
	
	
	else if(/^\/[a-zA-Z0-9\/]*.jpg$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "image/jpg");
		}else if(/^\/[a-zA-Z0-9\/]*.ico$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "image/x-ico");}
		
		
		
		
    else {
      
      console.log("callIndexhtml");
		sendFileContent(res, "index.html", "text/html");
			
     
      //res.writeHead(200, {
      //  "Content-Type": "text/html"
     // });
      //return res.end("<h1>�w����{Node.js�泾���O</h1><p><a href=\"/Signup\">���U</a></p>");
    }
  });

  server.listen(9000);

  console.log("Server is running�Atime is" + new Date());

  
  
  
  
  
function sendFileContent(response, fileName, contentType){
	fs.readFile(fileName, function(err, data){
		if(err){
			response.writeHead(404);
			response.write("Not Found!");
		}
		else{
			response.writeHead(200, {'Content-Type': contentType});
			response.write(data);
		}
		response.end();
	});
}
}).call(this);


